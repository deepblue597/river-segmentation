from setuptools import setup, find_packages

# Use pyproject.toml for metadata, this is just for package discovery
setup(
    packages=find_packages(),
)
